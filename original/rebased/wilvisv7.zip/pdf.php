

<!DOCTYPE html> 
<html> 
    <head> 
        <title>Télécharger en PDF</title> 
    </head> 
<body> 
    <h1>PDF</h1> 
    <script src="https://cdn.jsdelivr.net/npm/@grabzit/js@3.3.0/grabzit.min.js"></script>
    <script>
    GrabzIt("YjhhMTdkZDEyMjUyNDdhYzg3NzY1NWJiZmRmMTY0YTQ=").ConvertURL("http://127.0.0.1/demo7fonctionelle/WILVIS/consultation.php", 
    {"format": "jpg", "download": 1}).Create();
    </script>
</body> 
</html>
